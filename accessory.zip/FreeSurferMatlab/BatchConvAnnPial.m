function BatchConvAnnPial(path)
%function BatchConvAnnPial(path)

lsurf=strcat ('C:\Experiments\FreeSurferStudy\MICCAI11\', path, '\surf\lh.pial')
llabel=strcat ('C:\Experiments\FreeSurferStudy\MICCAI11\', path, '\label\lh.aparc.annot')
lout=strcat('C:\Experiments\FreeSurferStudy\MICCAI11\', path, '_lh.m')

AddAnnotation(lout, lsurf, llabel);

rsurf=strcat ('C:\Experiments\FreeSurferStudy\MICCAI11\', path, '\surf\rh.pial')
rlabel=strcat ('C:\Experiments\FreeSurferStudy\MICCAI11\', path, '\label\rh.aparc.annot')
rout=strcat('C:\Experiments\FreeSurferStudy\MICCAI11\', path, '_rh.m')

AddAnnotation(rout, rsurf, rlabel);
