function [  ] = generateMeshFile( vertices, faces, filename )
% Given the vertex matrix and face matrix, 
% this program writes them into a .m file.
% This program can be used in combination with freesurfer_read_surf.m
% which reads vertex and face information from the freesurfer results
% such as .pial, .whtie, .thickness, and .inflated 

fid = fopen(filename,'w');

indexV = 1:1:length(vertices);
indexF = 1:1:length(faces);

vertices = [indexV',vertices];
formatSpecV = 'Vertex %d %f %f %f {rgb=(0.671 0.329 0.000)}\n';
fprintf(fid,formatSpecV, vertices');

faces = [indexF',faces];
formatSpecF = 'Face %d %d %d %d\n';
fprintf(fid,formatSpecF, faces');

fclose(fid);

end

