function AddAnnotation(Outfile, surffile, labelfile)
% AddAnnotation(Outfile, surffile labelfile)

[q.vertices, q.faces]=read_surf(surffile);
[v,L, ct]=read_annotation(labelfile);

q.faces = q.faces +1;
vnum = size(q.vertices, 1)
fnum = size(q.faces, 1)
fid = fopen(Outfile, 'w');
for i=0:vnum-1,
%    if abs(rL(i+1) - 9182740) < 1e-5,
%        fprintf(fid, 'Vertex %d %f %f %f {annotation=(%d) rgb=(1.000 0 0)}\n', i+1, q.vertices(i+1), q.vertices(149722+i+1), q.vertices(149722*2+i+1), rL(i+1));
%    else
        fprintf(fid, 'Vertex %d %f %f %f {annotation=(%d) rgb=(0.671 0.329 0.000)}\n', i+1, q.vertices(i+1), q.vertices(vnum+i+1), q.vertices(vnum*2+i+1), L(i+1));
%    end        
end

for i=0:fnum-1,
    fprintf(fid, 'Face %d %d %d %d\n', i+1,  q.faces(i+1), q.faces(fnum+i+1), q.faces(fnum*2+i+1));
end
fclose(fid);