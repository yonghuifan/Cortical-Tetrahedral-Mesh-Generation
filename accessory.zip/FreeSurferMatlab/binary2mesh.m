function [  ] = binary2mesh( inFileName, outFileName )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

[vertices, faces] = freesurfer_read_surf(inFileName);
generateMeshFile(vertices, faces, outFileName);

end

