clear
%root = './V1/Congenitally Blind/';
%root = './V1/Sighted Control-CB/';
%root = './V1/Sighted Control-LB/';
root = './V1/Late Blind/';

folders = dir(root);

for folder = folders'
    if length(folder.name) < 3
        continue;
    end
    subFolders = dir ([root folder.name]);
    for subFolder = subFolders'
        if length(subFolder.name)< 3
            continue;
        end
        if (exist([root folder.name '/mesh']) == 0)
            mkdir ([root folder.name '/mesh']);
        end

        if strcmp(subFolder.name, 'surf')
            files = dir([root folder.name '/' subFolder.name]);
            for file = files'
                filename = file.name;
                [pathstr,name,ext] = fileparts(filename);
                if length(ext) > 3
                    if strcmp(ext, '.pial') || strcmp(ext, '.white')
                        inFileName = [root folder.name '/' subFolder.name '/' file.name];
                        outFileName = [root folder.name '/mesh/' name '_' ext(2:end) '.m'];
                        binary2mesh( inFileName, outFileName );
                    end
                end
            end
        end
    end
end
    


%binary2mesh( inFileName, outFileName );