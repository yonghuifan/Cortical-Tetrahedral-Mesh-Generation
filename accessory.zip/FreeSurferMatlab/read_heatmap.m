function [pos,tep] = read_heatmap(filename)
fid = fopen(filename);
A = fscanf(fid, '%d %f\n');
A = reshape(A, [2, length(A)/2]);
pos = A(1,:);
tep = A(2,:);
end

